﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sidercar.SidecarAPIModel
{
    public class InsModel
    {
        public string idTipo { get; set; }
        public string Latitud { get; set; }
        public string Longitud { get; set; }
        public string Velocidad { get; set; }
        public string Identificador { get; set; }
    }
}
