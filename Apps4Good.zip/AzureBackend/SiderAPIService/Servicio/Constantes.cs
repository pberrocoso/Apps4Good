﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiderAPIService.Servicio
{
    public static class Constantes
    {
        public const string RESULTERROR = "ERROR";
        public const string RESULTOK = "OK";
    }
}
