﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiderAPIService.Model
{
    public class Resultado
    {
        public string STATUS { get; set; }
    }
}
